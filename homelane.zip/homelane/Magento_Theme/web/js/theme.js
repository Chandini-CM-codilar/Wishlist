
const targetDiv = document.getElementById("minicart-content-wrapper");
const btn = document.getElementById("product-addtocart-button");
btn.onclick = function () {
  console.log("hai");
  if (targetDiv.style.display != "none") {
    targetDiv.style.display = "block";
  } else {
    targetDiv.style.display = "none";
  }
};